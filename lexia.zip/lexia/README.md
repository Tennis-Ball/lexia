# lexia
Simple Chrome extension to improve readability/reading speed of online text
